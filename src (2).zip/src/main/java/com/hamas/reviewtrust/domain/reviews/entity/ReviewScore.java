package com.hamas.reviewtrust.domain.reviews.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

@Entity
@Table(name = "review_scores")
public class ReviewScore {

    @EmbeddedId
    private Id id;

    @Column(nullable = false)
    private int score;

    @Column(nullable = false, length = 1)
    private String rank;

    @Column(name = "sakura_judge", nullable = false, length = 16)
    private String sakuraJudge;

    @Column(name = "flags", columnDefinition = "jsonb", nullable = false)
    private String flagsJson;

    @Column(name = "rules", columnDefinition = "jsonb", nullable = false)
    private String rulesJson;

    @Column(name = "metrics", columnDefinition = "jsonb", nullable = false)
    private String metricsJson;

    @Column(name = "computed_at", nullable = false)
    private Instant computedAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    protected ReviewScore() {
    }

    public ReviewScore(Id id, int score, String rank, String sakuraJudge, String flagsJson,
                       String rulesJson, String metricsJson, Instant computedAt, Instant updatedAt) {
        this.id = id;
        this.score = score;
        this.rank = rank;
        this.sakuraJudge = sakuraJudge;
        this.flagsJson = flagsJson;
        this.rulesJson = rulesJson;
        this.metricsJson = metricsJson;
        this.computedAt = computedAt;
        this.updatedAt = updatedAt;
    }

    @PrePersist
    public void onCreate() {
        if (computedAt == null) computedAt = Instant.now();
        if (updatedAt == null) updatedAt = computedAt;
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = Instant.now();
    }

    public Id getId() { return id; }
    public int getScore() { return score; }
    public String getRank() { return rank; }
    public String getSakuraJudge() { return sakuraJudge; }
    public String getFlagsJson() { return flagsJson; }
    public String getRulesJson() { return rulesJson; }
    public String getMetricsJson() { return metricsJson; }
    public Instant getComputedAt() { return computedAt; }
    public Instant getUpdatedAt() { return updatedAt; }

    public void setScore(int score) { this.score = score; }
    public void setRank(String rank) { this.rank = rank; }
    public void setSakuraJudge(String sakuraJudge) { this.sakuraJudge = sakuraJudge; }
    public void setFlagsJson(String flagsJson) { this.flagsJson = flagsJson; }
    public void setRulesJson(String rulesJson) { this.rulesJson = rulesJson; }
    public void setMetricsJson(String metricsJson) { this.metricsJson = metricsJson; }
    public void setComputedAt(Instant computedAt) { this.computedAt = computedAt; }

    @Embeddable
    public static class Id implements Serializable {
        @Column(name = "product_id", nullable = false)
        private UUID productId;

        @Column(name = "source", nullable = false, length = 16)
        private String source;

        public Id() {
        }

        public Id(UUID productId, String source) {
            this.productId = productId;
            this.source = source;
        }

        public UUID getProductId() { return productId; }
        public String getSource() { return source; }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Id id1)) return false;
            return Objects.equals(productId, id1.productId) && Objects.equals(source, id1.source);
        }

        @Override
        public int hashCode() {
            return Objects.hash(productId, source);
        }
    }
}
