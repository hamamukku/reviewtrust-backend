package com.hamas.reviewtrust.domain.reviews.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamas.reviewtrust.domain.reviews.entity.ReviewScore;
import com.hamas.reviewtrust.domain.reviews.repo.ReviewScoreRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class ScoreReadService {

    private final ReviewScoreRepository repository;
    private final ObjectMapper objectMapper;

    public ScoreReadService(ReviewScoreRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @Transactional(readOnly = true)
    public ProductScores latestByProduct(UUID productId) {
        ScoreDetail amazon = toDetail(repository.findByIdProductIdAndIdSource(productId, "AMAZON"));
        ScoreDetail site = toDetail(repository.findByIdProductIdAndIdSource(productId, "SITE"));
        return new ProductScores(amazon, site);
    }

    private ScoreDetail toDetail(Optional<ReviewScore> optional) {
        return optional.map(score -> new ScoreDetail(
                score.getScore(),
                score.getRank(),
                score.getSakuraJudge(),
                readJson(score.getFlagsJson()),
                readJson(score.getRulesJson()),
                readJson(score.getMetricsJson()),
                score.getComputedAt()
        )).orElse(null);
    }

    private JsonNode readJson(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            return objectMapper.readTree(raw);
        } catch (Exception e) {
            return null;
        }
    }

    public record ProductScores(ScoreDetail amazon, ScoreDetail site) {}

    public record ScoreDetail(int score,
                              String rank,
                              String sakuraJudge,
                              JsonNode flags,
                              JsonNode rules,
                              JsonNode metrics,
                              Instant computedAt) {}
}
