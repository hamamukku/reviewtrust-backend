package com.hamas.reviewtrust.api.publicapi.v1;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hamas.reviewtrust.domain.scoring.catalog.ScoreModels;
import com.hamas.reviewtrust.domain.scoring.engine.ScoreService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Public endpoint exposing a product's latest scoring snapshot.
 */
@RestController
@RequestMapping("/api/products")
public class ScoresController {

    private final ScoreService scoreService;

    public ScoresController(ScoreService scoreService) {
        this.scoreService = scoreService;
    }

    @GetMapping("/{id}/scores")
    public ResponseEntity<?> getScores(@PathVariable("id") String productId) {
        if (!isUuid(productId)) {
            return error(HttpStatus.BAD_REQUEST, "E_BAD_REQUEST", "product id must be a UUID");
        }
        try {
            Optional<ScoreModels.ScoreResult> result = scoreService.computeForProduct(productId);
            ScorePayload payload = result.map(this::toPayload).orElse(defaultPayload());
            return ResponseEntity.ok(new ScoreResponse(payload));
        } catch (Exception e) {
            return error(HttpStatus.INTERNAL_SERVER_ERROR, "E_INTERNAL", "Unable to compute score");
        }
    }

    private ScorePayload toPayload(ScoreModels.ScoreResult score) {
        Map<String, Map<String, Object>> rulesMap = new LinkedHashMap<>();
        for (ScoreModels.RuleDetail detail : score.rules) {
            rulesMap.put(detail.rule(), Map.of(
                    "value", detail.value(),
                    "warn", detail.warn(),
                    "weight", detail.weight(),
                    "penalty", detail.penalty()
            ));
        }
        return new ScorePayload(
                score.score,
                score.rank != null ? score.rank.name() : null,
                score.sakuraJudge != null ? score.sakuraJudge.name() : ScoreModels.SakuraJudge.GENUINE.name(),
                score.flags != null ? score.flags : List.of(),
                rulesMap
        );
    }

    private ScorePayload defaultPayload() {
        return new ScorePayload(null, null, ScoreModels.SakuraJudge.GENUINE.name(), List.of(), Map.of());
    }

    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status)
                .body(Map.of("error", Map.of("code", code, "message", message)));
    }

    private boolean isUuid(String value) {
        try {
            UUID.fromString(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ScorePayload(Integer score,
                                String rank,
                                @JsonProperty("sakura_judge") String sakuraJudge,
                                List<String> flags,
                                Map<String, ?> rules) { }

    public record ScoreResponse(ScorePayload amazon) { }
}
