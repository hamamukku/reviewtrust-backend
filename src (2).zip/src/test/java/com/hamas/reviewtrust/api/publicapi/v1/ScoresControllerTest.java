package com.hamas.reviewtrust.api.publicapi.v1;

import com.hamas.reviewtrust.domain.scoring.catalog.ScoreModels;
import com.hamas.reviewtrust.domain.scoring.engine.ScoreService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.hamcrest.Matchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ScoresController.class)
@ActiveProfiles("test")
public class ScoresControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ScoreService scoreService;

    @Test
    void returnsScorePayload() throws Exception {
        String productId = UUID.randomUUID().toString();
        ScoreModels.RuleDetail ruleDetail = new ScoreModels.RuleDetail("dist_bias>=warn", 0.52, 0.35, 0.35, 18);
        ScoreModels.ScoreResult result = new ScoreModels.ScoreResult(
                productId,
                82,
                ScoreModels.Rank.B,
                ScoreModels.SakuraJudge.UNLIKELY,
                Map.of("total_reviews", 42),
                List.of("ATTN_DISTRIBUTION"),
                List.of(ruleDetail),
                "2025-10-22T10:00:00Z"
        );
        Mockito.when(scoreService.computeForProduct(productId)).thenReturn(Optional.of(result));

        mockMvc.perform(get("/api/products/{id}/scores", productId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.amazon.score").value(82))
                .andExpect(jsonPath("$.amazon.rank").value("B"))
                .andExpect(jsonPath("$.amazon.sakura_judge").value("UNLIKELY"))
                .andExpect(jsonPath("$.amazon.flags[0]").value("ATTN_DISTRIBUTION"))
                .andExpect(jsonPath("$.amazon.rules['dist_bias>=warn'].penalty").value(18));
    }

    @Test
    void returnsDefaultsWhenScoreMissing() throws Exception {
        String productId = UUID.randomUUID().toString();
        Mockito.when(scoreService.computeForProduct(productId)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/products/{id}/scores", productId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.amazon.score").value(nullValue()))
                .andExpect(jsonPath("$.amazon.rank").value(nullValue()))
                .andExpect(jsonPath("$.amazon.sakura_judge").value("GENUINE"));
    }

    @Test
    void rejectsInvalidProductId() throws Exception {
        mockMvc.perform(get("/api/products/not-a-uuid/scores"))
                .andExpect(status().isBadRequest());
    }
}
