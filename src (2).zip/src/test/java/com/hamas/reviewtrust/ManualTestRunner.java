package com.hamas.reviewtrust;

import com.hamas.reviewtrust.api.publicapi.v1.ScoresController;
import com.hamas.reviewtrust.api.publicapi.v1.ScoresController.ScoreResponse;
import com.hamas.reviewtrust.domain.scoring.catalog.ScoreModels;
import com.hamas.reviewtrust.domain.scoring.engine.Ranker;
import com.hamas.reviewtrust.domain.scoring.engine.ScoreService;
import com.hamas.reviewtrust.domain.scoring.profile.ThresholdProvider;
import org.mockito.Mockito;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class ManualTestRunner {

    public static void main(String[] args) throws Exception {
        try {
            testRanker();
            testScoresControllerContract();
            testHealthEndpoint();
            System.out.println("MANUAL TESTS PASSED");
        } catch (AssertionError | Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void testRanker() {
        ThresholdProvider.Thresholds thresholds = ThresholdProvider.Thresholds.defaults();
        require(Ranker.assign(34).name().equals(ScoreModels.Rank.A.name()), "Score 34 should be rank A");
        require(Ranker.assign(35).name().equals(ScoreModels.Rank.B.name()), "Score 35 should be rank B");
        require(Ranker.assign(80).name().equals(ScoreModels.Rank.C.name()), "Score 80 should be rank C");

        ScoreModels.FeatureSnapshot suspicious = new ScoreModels.FeatureSnapshot(0.9, 0.6, 0.0, 0.0);
        require(
                Ranker.judgeSakura(suspicious, thresholds) == ScoreModels.SakuraJudge.SAKURA,
                "High bias + dup => SAKURA"
        );
    }

    private static void testScoresControllerContract() {
        ScoreService mock = Mockito.mock(ScoreService.class);
        ScoreModels.RuleDetail detail = new ScoreModels.RuleDetail("dist_bias>=warn", 0.52, 0.35, 0.35, 18);
        ScoreModels.ScoreResult result = new ScoreModels.ScoreResult(
                "123",
                82,
                ScoreModels.Rank.B,
                ScoreModels.SakuraJudge.UNLIKELY,
                Map.of("total_reviews", 42),
                List.of("ATTN_DISTRIBUTION"),
                List.of(detail),
                "2025-10-22T10:00:00Z"
        );
        String productId = "00000000-0000-0000-0000-000000000123";
        Mockito.when(mock.computeForProduct(productId)).thenReturn(Optional.of(result));

        ScoresController controller = new ScoresController(mock);
        ResponseEntity<?> response = controller.getScores(productId);
        require(response.getStatusCode().is2xxSuccessful(), "Scores endpoint should return 200");
        Object body = response.getBody();
        require(body instanceof ScoreResponse, "Response must be ScoreResponse");
        ScoreResponse payload = (ScoreResponse) body;
        require(payload != null, "Payload must not be null");
        require(payload.amazon() != null, "Amazon block must not be null");
        require(payload.amazon().score() == 82, "Score must be 82");
        require("B".equals(payload.amazon().rank()), "Rank must be B");
        require("UNLIKELY".equals(payload.amazon().sakuraJudge()), "Sakura judge must be UNLIKELY");
    }

    private static void testHealthEndpoint() {
        System.setProperty("spring.profiles.active", "test");
        ConfigurableApplicationContext ctx = SpringApplication.run(ReviewTrustApplication.class);
        try {
            HealthEndpoint endpoint = ctx.getBean(HealthEndpoint.class);
            HealthComponent component = endpoint.health();
            require(component.getStatus() != null, "Health status should not be null");
            require("UP".equalsIgnoreCase(component.getStatus().getCode()), "Health status must be UP");
        } finally {
            SpringApplication.exit(ctx);
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
